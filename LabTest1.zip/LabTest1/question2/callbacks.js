const resolvedPromise = () => {
    return new Promise(function(resolve, reject){
        setTimeout(() => {
            let success = {'message' : 'delayed success!'}
            console.log(success);
            resolve();
        }, 500);
    });
}

const rejectedPromise = () => {
    return new Promise(function(resolve, reject){
        setTimeout(() => {
            let error = 'error : delayed exception!';
            console.log(error);
            reject();
        }, 500);
    });
}

resolvedPromise();
rejectedPromise();